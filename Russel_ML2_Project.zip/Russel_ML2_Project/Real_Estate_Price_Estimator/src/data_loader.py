import pandas as pd
import os

def load_data(filepath='data/final.csv'):
    """
    Load the real estate dataset.

    Returns:
        df (DataFrame): The cleaned dataset.
    """
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"{filepath} not found.")
    
    df = pd.read_csv(filepath)

    required_columns = {
        'price', 'year_sold', 'property_tax', 'insurance', 'beds', 'baths',
        'sqft', 'year_built', 'lot_size', 'basement', 'popular',
        'recession', 'property_age', 'property_type_Condo'
    }

    if not required_columns.issubset(df.columns):
        raise ValueError(f"Missing columns: {required_columns - set(df.columns)}")
    
    return df