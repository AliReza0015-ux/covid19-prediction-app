import streamlit as st
import pandas as pd
from src.data_loader import load_data
from src.preprocessing import preprocess_data
from src.model import train_model, evaluate_model
from src.utils import plot_actual_vs_predicted

st.set_page_config(page_title="🏠 Real Estate Price Estimator", layout="wide")
st.title("🏠 Real Estate Price Estimator")

# Load data
df = load_data("data/final.csv")
st.write("### Sample Data", df.head())

# Preprocess
X_train, X_test, y_train, y_test, scaler = preprocess_data(df)

# Train model
model = train_model(X_train, y_train)

# Evaluate
r2, mse, predictions = evaluate_model(model, X_test, y_test)
st.write(f"### 📈 Model Performance")
st.metric("R² Score", round(r2, 3))
st.metric("Mean Squared Error", round(mse, 2))

# Plot predictions
fig = plot_actual_vs_predicted(y_test, predictions)
st.pyplot(fig)

# Input-based prediction
st.write("### 🧮 Try Predicting a House Price")

# Define which fields are integers
int_fields = [
    'year_sold', 'beds', 'baths', 'year_built', 'basement',
    'popular', 'recession', 'property_age', 'property_type_Condo'
]

with st.form("predict_form"):
    cols = df.drop(columns=['price']).columns.tolist()
    inputs = {}
    for col in cols:
        default = float(df[col].mean())
        if col in int_fields:
            inputs[col] = st.number_input(f"{col}", value=int(default), step=1, format="%d")
        else:
            inputs[col] = st.number_input(f"{col}", value=default)
    
    submitted = st.form_submit_button("Predict")

    if submitted:
        input_df = pd.DataFrame([inputs])
        input_scaled = scaler.transform(input_df)
        prediction = model.predict(input_scaled)[0]
        st.success(f"🏷️ Estimated Price: **${prediction:,.0f}**")