# 🏠 Real Estate Price Estimator

This Streamlit web application predicts real estate property prices using a machine learning regression model trained on historical housing data. It enables users to explore the dataset, understand model performance, and input custom property features to estimate a sale price.

---

## 📊 Dataset

**File**: `final.csv`  
**Source**: Provided as part of course materials

### 🔍 Features Used:
| Feature               | Description                                 |
|------------------------|---------------------------------------------|
| `year_sold`            | Year the property was sold                  |
| `property_tax`         | Annual property tax                         |
| `insurance`            | Insurance cost                              |
| `beds`, `baths`        | Number of bedrooms and bathrooms            |
| `sqft`                | Total square footage                        |
| `year_built`          | Year the house was constructed              |
| `lot_size`            | Lot size in square feet                     |
| `basement`            | 1 if basement present, else 0               |
| `popular`             | 1 if in a desirable location                |
| `recession`           | 1 if sold during recession                  |
| `property_age`        | Calculated as year_sold - year_built        |
| `property_type_Condo` | 1 if the property is a condo, else 0        |

**Target Variable**: `price` (property sale price in USD)

---

## 🧠 Model Used

- **Linear Regression** (`sklearn.linear_model.LinearRegression`)
- Performance metrics:
  - R² Score
  - Mean Squared Error (MSE)
- Scaled input features using `StandardScaler`

---

## 🚀 Features

- Load and preview real estate dataset
- Preprocess features and train regression model
- Evaluate model with R² score and MSE
- Visualize actual vs predicted prices
- Allow users to input their own property features and estimate the price

---

## 🛠 How to Run the App Locally

### 1. Clone the Repository

```bash
git clone https://github.com/your-username/Real_Estate_Price_Estimator.git
cd Real_Estate_Price_Estimator

## 🌐 Live App

You can try the deployed Streamlit app here:  
🔗 [Real Estate Price Estimator](https://realestatepriceestimator-russel.streamlit.app/)
