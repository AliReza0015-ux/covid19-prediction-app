def preprocess_data(df):
    return df[['Annual Income (k$)', 'Spending Score (1-100)']]
